<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 8/13/16
 * Time: 8:28 PM
 */

return [
    'action'            => '- Select an Action -',
    'activate'          => 'Activate',
    'deactivate'        => 'Deactivate',
    'delete'            => 'Delete Permanently',
    'reject'			=> 'Reject',
    'approved'			=> 'Approve',
    'post'              => 'Post',
    'placeholderFilter' => 'Type to search...'
];