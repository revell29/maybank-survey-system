<?php $__env->startSection('title', 'Dashboard - Home'); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/global_assets/js/plugins/tables/datatables/datatables.min.js"></script>
<script type="text/javascript" src="/global_assets/js/plugins/tables/datatables/extensions/select.min.js"></script>
<script type="text/javascript" src="/global_assets/js/plugins/forms/selects/select2.min.js"></script>
<script type="text/javascript" src="/global_assets/js/plugins/notifications/sweet_alert.min.js"></script>
<script type="text/javascript" src="/global_assets/js/plugins/forms/styling/uniform.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Page header -->
<div class="page-header page-header-light">
    <div class="page-header-content header-elements-md-inline">
        <div class="page-title d-flex">
            <h4><span class="font-weight-semibold">Master Data</span> - <?php echo e(isset($data) ? 'Edit Role' : 'Add Role'); ?></h4>
            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>

        <div class="header-elements d-none">
            
        </div>
    </div>

    <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
        <div class="d-flex">
            <div class="breadcrumb">
                <a href="<?php echo e(route('role.index')); ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Home</a>
                <a href="#" class="breadcrumb-item">Master Data</a>
                <span class="breadcrumb-item active"><?php echo e(isset($data) ? 'Edit Role' : 'Add Role'); ?></span>
            </div>

            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>
    </div>
</div>
<!-- /page header -->

<!-- Main content -->
<div class="content">
    <form id="form-role">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header header-elements-inline">
                        <h5 class="card-title"><?php echo e(isset($data) ? 'Edit Role' : 'Add Role'); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Role Name</label>
                            <input type="text" class="form-control notif" name="name"
                                value="<?php echo e(isset($data) ? $data->name : null); ?>">
                            <label class="validation-invalid-label notif" id="name"></label>
                        </div>
                        <div class="form-group">
                            <label>Role Description</label>
                            <?php echo Form::textarea('description', isset($data) ? $data->description : null, ['class' =>
                            'form-control m-input', 'placeholder' => 'Enter Description']); ?>

                            <label class="validation-invalid-label notif" id="description"></label>
                        </div>
                        <div class="form-group">
                            <label>Privileges</label>
                            <label class="validation-invalid-label notif" id="permission-notif"></label>
                            <div class="row">
                                <div class="col-md-3">
                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <label class="form-check-label">
                                            <div class="">
                                                <span class="">
                                                    <?php echo Form::checkbox('permissions[]', $p->id, isset($data) ?
                                                    $data->hasPermission($p->name) : '',['class' =>
                                                    'form-check-input-styled']); ?>

                                                </span>
                                            </div>
                                            <?php echo e($p->display_name); ?>

                                        </label>
                                    </div>
                                    <?php if($loop->iteration == 4) break; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-md-3">
                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($p->id < 5) continue; ?>
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <div class="">
                                                    <span class="">
                                                        <?php echo Form::checkbox('permissions[]', $p->id, isset($data) ?
                                                        $data->hasPermission($p->name) : '',['class' =>
                                                        'form-check-input-styled']); ?>

                                                    </span>
                                                </div>
                                                <?php echo e($p->display_name); ?>

                                            </label>
                                        </div>
                                    <?php if($loop->iteration == 8) break; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-md-3">
                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($p->id < 9) continue; ?>
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <div class="">
                                                    <span class="">
                                                        <?php echo Form::checkbox('permissions[]', $p->id, isset($data) ?
                                                        $data->hasPermission($p->name) : '',['class' =>
                                                        'form-check-input-styled']); ?>

                                                    </span>
                                                </div>
                                                <?php echo e($p->display_name); ?>

                                            </label>
                                        </div>
                                    <?php if($loop->iteration == 12) break; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-md-3">
                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($p->id < 13) continue; ?>
                                        <div class="form-check">
                                            <label class="form-check-label">
                                                <div class="">
                                                    <span class="">
                                                        <?php echo Form::checkbox('permissions[]', $p->id, isset($data) ?
                                                        $data->hasPermission($p->name) : '',['class' =>
                                                        'form-check-input-styled']); ?>

                                                    </span>
                                                </div>
                                                <?php echo e($p->display_name); ?>

                                            </label>
                                        </div>
                                    <?php if($loop->iteration == 16) break; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <br>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-3">
                                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($p->id < 17) continue; ?>
                                            <div class="form-check">
                                                <label class="form-check-label">
                                                    <div class="">
                                                        <span class="">
                                                            <?php echo Form::checkbox('permissions[]', $p->id, isset($data) ?
                                                            $data->hasPermission($p->name) : '',['class' =>
                                                            'form-check-input-styled']); ?>

                                                        </span>
                                                    </div>
                                                    <?php echo e($p->display_name); ?>

                                                </label>
                                            </div>
                                        <?php if($loop->iteration == 20) break; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="col-md-3">
                                        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($p->id < 21) continue; ?>
                                            <div class="form-check">
                                                <label class="form-check-label">
                                                    <div class="">
                                                        <span class="">
                                                            <?php echo Form::checkbox('permissions[]', $p->id, isset($data) ?
                                                            $data->hasPermission($p->name) : '',['class' =>
                                                            'form-check-input-styled']); ?>

                                                        </span>
                                                    </div>
                                                    <?php echo e($p->display_name); ?>

                                                </label>
                                            </div>
                                        <?php if($loop->iteration == 24) break; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="text-right">
                        <?php if (\Entrust::can('create_role')) : ?>
                        <button type="button" id="save" class="btn btn-md btn-primary pull-right">Submit</button>
                        <?php endif; // Entrust::can ?>
                        <a href="<?php echo e(route('role.index')); ?>" class="btn btn-md btn-danger">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<!-- /main content -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scriptcode'); ?>
<script type="text/javascript">
    $('#save').on('click', function () {
        var btn = $(this);
        $.ajax({
            url: '<?php echo e(isset($data) ? route('role.update',$data->id) : route('role.store')); ?>',
            data: $('#form-role').serialize(),
            dataType: 'json',
            type: '<?php echo e(isset($data) ? 'PATCH' : 'POST'); ?>',
            beforeSend: function (xhr, $form) {
                btn.html('Please wait').prop('disabled', true);
                $('.form-group').removeClass('has-danger');
            },
            success: function (response, xhr, status, $form) {
                swal({
                    title: "Success!",
                    text: response.message,
                    type: "success",
                    buttonsStyling: false,
                    confirmButtonClass: 'btn btn-primary btn-lg',
                }).then(function () {
                    // Redirect the user
                    window.location.href = "/master/role";
                });
            },
            error: function (response, status) {
                if (response.status == 500) {
                    btn.html('Submit').prop('disabled', false);
                    swal("Error", response.message, 'error');
                }
                if (response.status == 422) {
                    btn.html('Submit').prop('disabled', false);
                    var error = response.responseJSON.errors;
                    if (error.name) $('#name').html(error.name[0]);
                    if (error.display_name) $('#display_name').html(error.display_name[0]);
                    if (error.permission) $('#permission-notif').html(error.permission[0]);
                }
            }
        });
        return false;
    });
    $('.form-check-input-styled').uniform();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>