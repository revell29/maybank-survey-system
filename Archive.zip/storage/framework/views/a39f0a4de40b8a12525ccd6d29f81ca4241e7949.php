<?php $__env->startSection('title', 'Dashboard - Home'); ?>

<?php $__env->startSection('content'); ?>

   <!-- Page header -->
        <div class="page-header page-header-light">
            <div class="page-header-content header-elements-md-inline">
                <div class="page-title d-flex">
                    <h4><i class="icon-arrow-left52 mr-2"></i> <span class="font-weight-semibold">Dashboard</span></h4>
                    <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
                </div>

                <div class="header-elements d-none">
                    
                </div>
            </div>

            <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
                

                
            </div>
        </div>
	<!-- /page header -->

    <!-- Main content -->
    <div class="content">
        <div class="card">
            <div class="card-header header-elements-inline">
               
            </div>

            <div class="card-body">
                <center><h1>Welcome <?php echo e(Auth::user()->name); ?></h1></center>
            </div>
        </div>
    </div>
    <!-- /main content -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scriptcode'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>