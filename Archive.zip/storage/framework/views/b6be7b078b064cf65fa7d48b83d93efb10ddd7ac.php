<?php $__env->startSection('title', 'Dashboard - Home'); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/global_assets/js/plugins/tables/datatables/datatables.min.js"></script>
<script type="text/javascript" src="/global_assets/js/plugins/tables/datatables/extensions/select.min.js"></script>
<script type="text/javascript" src="/global_assets/js/plugins/forms/selects/select2.min.js"></script>
<script type="text/javascript" src="/global_assets/js/plugins/notifications/sweet_alert.min.js"></script>
<script type="text/javascript" src="/global_assets/js/plugins/forms/styling/uniform.min.js"></script>
<script type="text/javascript" src="/custom/datatables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Page header -->
<div class="page-header page-header-light">
    <div class="page-header-content header-elements-md-inline">
        <div class="page-title d-flex">
            <h4><span class="font-weight-semibold">Master Data</span> - User</h4>
            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>

        <div class="header-elements d-none">
            <?php if (\Entrust::can('create_user')) : ?>
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-labeled btn-labeled-left bg-primary">Add User <b><i
                        class="icon-add"></i></b></a>
            <?php endif; // Entrust::can ?>
        </div>
    </div>

    <div class="breadcrumb-line breadcrumb-line-light header-elements-md-inline">
        <div class="d-flex">
            <div class="breadcrumb">
                <a href="<?php echo e(route('user.index')); ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Home</a>
                <a href="#" class="breadcrumb-item">Master Data</a>
                <span class="breadcrumb-item active">User</span>
            </div>

            <a href="#" class="header-elements-toggle text-default d-md-none"><i class="icon-more"></i></a>
        </div>
    </div>
</div>
<!-- /page header -->

<!-- Main content -->
<div class="content">
    <div class="card">
        <table class="table table-hover table-bordered table-xxs datatable-select-checkbox" id="data-table"
            data-url="<?php echo e(route('user.index')); ?>">
            <thead>
                <tr>
                    <th><input type="checkbox" class="styled" id="select-all"></th>
                    <th>ID</th>
                    <th>UserID</th>
                    <th>Username</th>
                    <th>Role</th>
                </tr>
            </thead>
        </table>
    </div>
</div>
<!-- /main content -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scriptcode'); ?>
<script type="text/javascript">
    var table = $('#data-table').DataTable({
        order: [1, 'desc'],
        ajax: '<?php echo e(route('User::list')); ?>',
        columnDefs: [{
            targets: 0,
            createdCell: function(td, cellData) {
                if (cellData != 1) {
                    $(td).addClass('select-checkbox')
                }
            }
        }],
        columns: [
            { data: 'id', name: 'id', width: '50px', orderable: false, render: function() { return ''} },
            { data: 'id', name: 'id', width: '30px', class: "text-center" },
            { data: 'user_id', name: 'user_id' },
            { data: 'username', name: 'username', searchable: true},
            { data: 'role_name', name: 'role_name', defaultContent: ''},
        ]
    })

    table.on('select',function(){
        table.rows('#1').deselect();
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>